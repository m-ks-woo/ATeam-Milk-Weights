# ATeam-Milk-Weights
README

Course: cs400
Semester: Spring 2020
Project name: Milk Weights
Team Members:
1. Matthew Woo, LEC002, mkwoo@wisc.edu
2. Russell Cheng, LEC002, rrcheng@wisc.edu
3. Param Bhandare, LEC001, pbhandare@wisc.edu
